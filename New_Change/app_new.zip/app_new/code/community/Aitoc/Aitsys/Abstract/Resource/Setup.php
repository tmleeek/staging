<?php

abstract class Aitoc_Aitsys_Abstract_Resource_Setup extends Mage_Core_Model_Resource_Setup 
implements Aitoc_Aitsys_Abstract_Model_Interface
{
    
    /**
     * 
     * @return Aitoc_Aitsys_Abstract_Service
     */
    public function tool()
    {
        return Aitoc_Aitsys_Abstract_Service::get();
    }
    
}