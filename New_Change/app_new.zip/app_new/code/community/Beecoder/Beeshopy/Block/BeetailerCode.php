<?php
/**
 * Beetailer checkout tracking code
 *
 * @category   Beetailer
 * @package    Beecoder_Beeshopy
*/

class Beecoder_Beeshopy_Block_BeetailerCode extends Mage_Core_Block_Template 
{
}
