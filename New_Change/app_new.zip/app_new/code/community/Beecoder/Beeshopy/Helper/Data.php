<?php
/**
 * Beetailer Data helper
 *
 * @category   Beetailer
 * @package    Beecoder_Beeshopy
*/


class Beecoder_Beeshopy_Helper_Data extends Mage_Core_Helper_Abstract
{

}
